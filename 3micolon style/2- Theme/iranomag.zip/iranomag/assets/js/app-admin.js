jQuery(document).ready(function ($) {
    // Customizing to add 18 color palettes
    if (typeof $.wp !== 'undefined' && typeof $.wp.wpColorPicker !== 'undefined') {
        $.wp.wpColorPicker.prototype.options = {
            width: 320,
            hide: true,
            border: false,
            palettes: ['#ededed', '#ecf0f1', '#c8d6e5', '#7f8c8d', '#34495e', '#22313f', '#2ecc71', '#48b56a', '#0abde3', '#1f8dd6', '#2574a9', '#1f3a93', '#5f27cd', '#fad232', '#ff9f43', '#ed6789', '#ff6b6b', '#ee5253'],
        };
    }
});