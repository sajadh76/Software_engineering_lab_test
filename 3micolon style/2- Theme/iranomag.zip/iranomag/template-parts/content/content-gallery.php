<?php
/**
 * Template part for displaying posts.
 */
?>