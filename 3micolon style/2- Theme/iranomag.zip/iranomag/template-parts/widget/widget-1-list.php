<?php
/**
 * Template part for displaying posts.
 *
 * @package iranomag
 */

?>

<li class="widget-<?php esc_attr(the_ID()); ?> im-widget-list clearfix">
	<div class="im-widget-entry-list">
		<header class="im-widget-entry-header">
            <?php if (!is_single()) : ?>
                <?php the_title( '<h3 class="im-widget-entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><span class="entry-title">', '</span></a></h3>' ); ?>
            <?php else: ?>
                <?php the_title( '<strong class="im-widget-entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><span class="entry-title">', '</span></a></strong>' ); ?>
            <?php endif; ?>
		</header>
		<footer class="im-widget-entry-footer">
			<?php im_meta(true, true, false, true, false, false); ?>
		</footer>
	</div>
</li>
