<div class="im-topnav <?php esc_attr(dl_select(ot_get_option("topnav_color"))); ?><?php if(esc_html(ot_get_option("topnav_full")) == "off") echo " container"; ?>">
    <div<?php if(esc_html(ot_get_option("topnav_full") == "on")) echo " class='container'"; ?>>
        <?php
            if ( has_nav_menu( 'top' ) ) {
                wp_nav_menu(
                array(
                        'theme_location'     => 'top',
                        'container_class'    => 'top-menu col-md-8',
                        'menu_id'            => 'top-menu',
                        'depth'              => '2',
                        'walker'             => new Simple_Walker
                    )
                );
            }
        ?>
        <div class="im-search im-<?php if(ot_get_option('menu_btn') == 'auto') echo 'slide'; else echo 'click' ?>-block pull-left">
            <div class="search-btn slide-btn" >
                <i class="fa iw-icon icon-magnifier"></i>
                <div class="im-search-panel im-slide-panel">
                    <?php get_template_part( 'searchform'); ?>
                </div>
            </div>
        </div>
        <div class="im-social im-<?php if(ot_get_option('menu_btn') == 'auto') echo 'slide'; else echo 'click' ?>-block pull-left">
            <div class="social-btn slide-btn" >
                <i class="fa iw-icon icon-share"></i>
                <div class="im-social-panel im-slide-panel">
                    <?php esc_html(social_link()); ?>
                </div>
            </div>
        </div>
    </div>
</div>