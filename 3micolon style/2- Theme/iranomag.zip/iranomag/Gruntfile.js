module.exports = function (grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        uglify: {
            dist: {
                files: {
                    'assets/js/app.min.js': [
                        'assets/js/app.js'
                    ],
                    'assets/js/voter-script.min.js': [
                        'assets/js/voter-script.js'
                    ],
                }
            }
        },
        // concat: {
        //   options: {
        //       stripBanners: true
        //   },
        //   dist: {
        //       src: ['assets/js/min/bootstrap-rtl.min.js', 'assets/js/min/lightslider.min.js', 'assets/js/min/jquery-sticky-kit.min.js', 'assets/js/min/lazy-load.min.js', 'assets/js/min/lightbox.min.js', 'assets/js/min/enquire.min.js', 'assets/js/min/app.min.js'],
        //       dest: 'assets/js/bundle.min.js',
        //   },
        // },
        cssmin: {
            dist: {
                files: {
                    'assets/css/site.min.css': ['assets/css/site.css']
                }
            }
        },
        watch: {
            uglify: {
                files: [
                    'assets/js/*'
                ],
                tasks: ['uglify']
            },
            // concat: {
            //   files: [
            //       'assets/js/min/*'
            //   ],
            //   tasks: ['concat']
            // },
            cssmin: {
                files: [
                    'assets/css/site.css'
                ],
                tasks: ['cssmin']
            }
        }
    });
    grunt.loadNpmTasks('grunt-contrib-uglify');
    // grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.registerTask('default', [
        'uglify',
        // 'concat',
        'cssmin',
        'watch',
    ]);
};