<?php
/**
 * Review Comments Template
 *
 * Closing li is left out on purpose!.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/review.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<li <?php comment_class(empty( $args['has_children'] ) ? '' :'parent') ?> id="comment-<?php comment_ID() ?>" itemscope itemtype="http://schema.org/Comment">
    <div class="im-comment-box clearfix">
        <div class="im-comment-details clearfix">
            <div class="im-comment-avatar pull-right">
                <figure class="im-gravatar"><?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, '50' ); ?></figure>
            </div>
            <div class="im-post-meta im-comment-meta position-relative" role="complementary">
                <div class="comment-author">
                    <strong>
                        <a class="comment-author-link" href="<?php esc_url(comment_author_url()); ?>"><?php comment_author(); ?></a>
                    </strong>
                </div>
                <div class="clearfix">
                    <div class="pull-right">
                        <span class="comment-meta-time"><?php comment_date(ot_get_option('date_layout')) ?>, <a href="#comment-<?php comment_ID() ?>"><?php comment_time() ?></a></span>
						<?php edit_comment_link('<i class="fa fa-edit"></i>','',''); ?>
						<?php if ($comment->comment_approved == '0') : ?>
                            <span class="im-comment-meta-item"><i class="fa fa-info"></i><?php esc_html_e( 'Comment awaiting moderation', 'im' ); ?></span>
						<?php endif; ?>
                    </div>
                    <div class="pull-left">
						<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
                        <?php do_action( 'woocommerce_review_before_comment_meta', $comment ); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="comment-content wc-comment-content clearfix">
			<?php
                do_action( 'woocommerce_review_comment_text', $comment );
                do_action( 'woocommerce_review_after_comment_text', $comment );
            ?>
        </div>
    </div>
</li>
