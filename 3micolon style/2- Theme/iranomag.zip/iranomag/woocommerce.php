<?php
get_header(); ?>
    <div id="primary">
        <div class="im-store-home clearfix">
			<?php woocommerce_content(); ?>
        </div>
    </div>
<?php
get_footer();
